CREATE TABLE Employee  
(  
EmployeeID int,  
EmployeeName nvarchar(255),   
Email nvarchar(255),   
AddressLine nvarchar(255),  
City nvarchar(255),
ManagerName nvarchar(50)
);

INSERT INTO Employee(EmployeeID,EmployeeName,Email,AddressLine,City,ManagerName)
VALUES(901,'Rahul','Rahul@gmail.com', 'M1','Hyderabad','Naveen'),
      (902,'Harsh','Harsh@gmail.com','M2','Suryapet','Aradhya'),
	  (903,'Betoo','betoo@gmail.com','M3','vizag','Latha');

--1--

Select * from Customer Where Country = 'Germany'

--2--

Select Firstname+' '+LastName as FullName from Customer

--3--

Select * from Customer Where FaxNumber IS Not Null

--4--

Select * from Customer Where FirstName Like '_U%'

--5--

Select *
From Orders
Left Outer Join
OrderItem 
On Orderr.id = OrderItem.Orderid
Where UnitPrice BETWEEN 10 AND 20 

--6--

Select * from Orderr 
Where ShippingDate IS NOT NULL 
Order By OrderDate

--7--

Select id, OrderNumber FROM Orderr 
Where ShipName = 'La corned ' AND 
		OrderDate BETWEEN 1/1/2020 AND 31/12/2020

--8--

Select id, ProductName 
From Product 
Where Supplier = 'Exotic Liquids'

--9--

Select AVG(Quantity) as AvgQuantity 
From Product p
     Right Outer Join
	 OrderItem o
	 On p.id = o.Productid

--10--

Select EmployeeName , ManagerName 
	 From Employee 

--11--


--12--

Select  TotalPrice 
From Orders 
Where Supplier = 'Exotic Liquids' AND TotalPrice > 50 




